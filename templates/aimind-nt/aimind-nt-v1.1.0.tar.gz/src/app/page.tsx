import Image from "next/image";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export default function Home() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background text-foreground">
      <main className="w-full max-w-3xl px-8 py-24">
        <section className="flex w-full flex-col items-center gap-6 rounded-lg border bg-card p-10 text-center">
          <Image
            src="/aim-logo.svg"
            alt="AIMind logo"
            width={220}
            height={60}
            className="dark:invert"
            priority
          />

          <h1 className="text-3xl font-semibold leading-9 tracking-tight">
            AIMIND TEMPLATE — NEXT + SHADCN
          </h1>

          <p className="max-w-prose text-lg text-muted-foreground">
            AiMind&apos;s clean starter template using shadcn components for a consistent look and feel.
          </p>

          <div className="flex gap-3">
            <Link href="https://aimind.vn">
              <Button variant="default">Visit Our Company</Button>
            </Link>
          </div>
        </section>
      </main>
    </div>
  );
}
