import pytest
import asyncio
from typing import AsyncGenerator
from unittest.mock import AsyncMock

from core.identity.domains.user import User
from core.identity.ports.repos.user_repo import UserRepository
from core.identity.ports.repos.token_repo import TokenRepository
from core.identity.ports.services.auth_service import AuthService
from core.identity.ports.services.email_service import EmailService
from shared.constants.auth_providers_enum import UserStatus


@pytest.fixture(scope="session")
def event_loop():
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def mock_user_repo() -> AsyncMock:
    """Mock user repository."""
    return AsyncMock(spec=UserRepository)


@pytest.fixture
def mock_token_repo() -> AsyncMock:
    """Mock token repository."""
    return AsyncMock(spec=TokenRepository)


@pytest.fixture
def mock_auth_service() -> AsyncMock:
    """Mock authentication service."""
    return AsyncMock(spec=AuthService)


@pytest.fixture
def mock_email_service() -> AsyncMock:
    """Mock email service."""
    return AsyncMock(spec=EmailService)


@pytest.fixture
def sample_user() -> User:
    """Create a sample user for testing."""
    return User(
        id=1,
        email="test@example.com",
        first_name="Test",
        last_name="User",
        status=UserStatus.ACTIVE,
        email_verified=True,
    )


@pytest.fixture
def sample_pending_user() -> User:
    """Create a sample pending user for testing."""
    return User(
        id=2,
        email="pending@example.com",
        first_name="Pending",
        last_name="User",
        status=UserStatus.PENDING,
        email_verified=False,
    )
