import pytest
from datetime import datetime, timedelta

from core.identity.domains.user import User
from shared.constants.auth_providers_enum import UserStatus


class TestUser:
    """Test cases for User domain entity."""

    @pytest.fixture
    def user(self) -> User:
        return User(
            id=1,
            email="test@example.com",
            first_name="Test",
            last_name="User",
            status=UserStatus.ACTIVE,
        )

    def test_set_password(self, user):
        """Test password hashing."""
        password = "test_password_123"
        user.set_password(password)

        assert user.password_hash is not None
        assert user.password_hash != password  # Should be hashed

    def test_verify_password_correct(self, user):
        """Test password verification with correct password."""
        password = "test_password_123"
        user.set_password(password)

        assert user.verify_password(password) is True

    def test_verify_password_incorrect(self, user):
        """Test password verification with incorrect password."""
        user.set_password("correct_password")

        assert user.verify_password("wrong_password") is False

    def test_verify_password_no_hash(self, user):
        """Test password verification when no hash is set."""
        assert user.verify_password("any_password") is False

    def test_can_login_active_user(self, user):
        """Test login permission for active user."""
        user.status = UserStatus.ACTIVE
        assert user.can_login() is True

    def test_can_login_pending_user(self, user):
        """Test login permission for pending user."""
        user.status = UserStatus.PENDING
        assert user.can_login() is False

    def test_can_login_locked_user(self, user):
        """Test login permission for locked user."""
        user.status = UserStatus.ACTIVE
        user.locked_until = datetime.utcnow() + timedelta(minutes=30)
        assert user.can_login() is False

    def test_verify_email(self, user):
        """Test email verification."""
        user.status = UserStatus.PENDING
        user.email_verified = False

        user.verify_email()

        assert user.email_verified is True
        assert user.email_verified_at is not None
        assert user.status == UserStatus.ACTIVE

    def test_record_failed_login(self, user):
        """Test recording failed login attempts."""
        initial_attempts = user.failed_login_attempts

        user.record_failed_login(max_attempts=3)

        assert user.failed_login_attempts == initial_attempts + 1

    def test_record_failed_login_lock_account(self, user):
        """Test account locking after max failed attempts."""
        user.failed_login_attempts = 4

        user.record_failed_login(max_attempts=5)

        assert user.failed_login_attempts == 5
        assert user.locked_until is not None

    def test_record_successful_login(self, user):
        """Test recording successful login."""
        user.failed_login_attempts = 3
        user.locked_until = datetime.utcnow() + timedelta(minutes=30)

        user.record_successful_login()

        assert user.last_login_at is not None
        assert user.failed_login_attempts == 0
        assert user.locked_until is None

    def test_get_full_name(self, user):
        """Test getting full name."""
        assert user.get_full_name() == "Test User"

        user.first_name = "John"
        user.last_name = "Doe"
        assert user.get_full_name() == "John Doe"
