import pytest
from unittest.mock import AsyncMock

from application.identity.use_cases.register_user import RegisterUserUseCase
from application.identity.dtos import RegisterRequest
from core.identity.domains.user import User
from shared.constants.auth_providers_enum import UserStatus, TokenType


class TestRegisterUserUseCase:
    """Test cases for RegisterUserUseCase."""

    @pytest.fixture
    def register_request(self) -> RegisterRequest:
        return RegisterRequest(
            email="newuser@example.com",
            password="SecurePass123!",
            first_name="New",
            last_name="User",
        )

    @pytest.fixture
    def use_case(
        self, mock_user_repo, mock_auth_service, mock_email_service
    ) -> RegisterUserUseCase:
        return RegisterUserUseCase(
            user_repo=mock_user_repo,
            auth_service=mock_auth_service,
            email_service=mock_email_service,
        )

    async def test_register_user_success(
        self,
        use_case,
        register_request,
        mock_user_repo,
        mock_auth_service,
        mock_email_service,
    ):
        """Test successful user registration."""
        # Arrange
        mock_user_repo.email_exists.return_value = False
        created_user = User(
            id=1,
            email=register_request.email,
            first_name=register_request.first_name,
            last_name=register_request.last_name,
            status=UserStatus.PENDING,
        )
        mock_user_repo.create.return_value = created_user
        mock_auth_service.generate_email_token.return_value = "token123"
        mock_email_service.send_verification_email.return_value = True

        # Act
        result = await use_case.execute(register_request)

        # Assert
        assert result.email == register_request.email
        assert result.first_name == register_request.first_name
        assert result.last_name == register_request.last_name
        assert result.status == UserStatus.PENDING
        assert not result.email_verified

        mock_user_repo.email_exists.assert_called_once_with(register_request.email)
        mock_user_repo.create.assert_called_once()
        mock_auth_service.generate_email_token.assert_called_once()
        mock_email_service.send_verification_email.assert_called_once()

    async def test_register_user_email_already_exists(
        self, use_case, register_request, mock_user_repo
    ):
        """Test registration with existing email."""
        # Arrange
        mock_user_repo.email_exists.return_value = True

        # Act & Assert
        with pytest.raises(ValueError, match="Email already registered"):
            await use_case.execute(register_request)

        mock_user_repo.email_exists.assert_called_once_with(register_request.email)
        mock_user_repo.create.assert_not_called()
