#!/usr/bin/env python3
"""Main application entry point."""

import uvicorn
from interfaces.api.bootstrap import create_app
from shared.settings import get_settings


def main():
    """Run the application."""
    settings = get_settings()
    app = create_app()

    # Run with uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8001,
        reload=settings.debug,
        log_level="debug" if settings.debug else "info",
    )


# Create app instance for uvicorn
app = create_app()


if __name__ == "__main__":
    main()
