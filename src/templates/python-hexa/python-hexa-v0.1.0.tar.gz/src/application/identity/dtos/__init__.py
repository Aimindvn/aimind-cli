from datetime import datetime
from typing import Optional, Dict, Any
from pydantic import BaseModel, EmailStr, Field

from shared.constants.auth_providers_enum import AuthProvider, UserStatus


# Request DTOs
class RegisterRequest(BaseModel):
    """User registration request DTO."""

    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    first_name: str = Field(min_length=1, max_length=50)
    last_name: str = Field(min_length=1, max_length=50)


class LoginRequest(BaseModel):
    """User login request DTO."""

    email: EmailStr
    password: str


class OAuthLoginRequest(BaseModel):
    """OAuth login request DTO."""

    provider: AuthProvider
    code: str
    state: Optional[str] = None
    redirect_uri: str


class RefreshTokenRequest(BaseModel):
    """Refresh token request DTO."""

    refresh_token: str


class ForgotPasswordRequest(BaseModel):
    """Forgot password request DTO."""

    email: EmailStr


class ResetPasswordRequest(BaseModel):
    """Reset password request DTO."""

    token: str
    new_password: str = Field(min_length=8, max_length=72)


class VerifyEmailRequest(BaseModel):
    """Verify email request DTO."""

    token: str


class VerifyOTPRequest(BaseModel):
    """Verify OTP request DTO."""

    email: EmailStr
    otp_code: str = Field(min_length=6, max_length=6)


# Response DTOs
class UserResponse(BaseModel):
    """User response DTO."""

    id: int
    email: str
    first_name: str
    last_name: str
    status: UserStatus
    email_verified: bool
    created_at: Optional[datetime] = None
    last_login_at: Optional[datetime] = None


class AuthTokenResponse(BaseModel):
    """Authentication token response DTO."""

    access_token: str
    refresh_token: str
    token_type: str = "Bearer"
    expires_in: int
    user: UserResponse


class MessageResponse(BaseModel):
    """Generic message response DTO."""

    message: str
    success: bool = True


class OAuthUrlResponse(BaseModel):
    """OAuth authorization URL response DTO."""

    authorization_url: str
    state: str
