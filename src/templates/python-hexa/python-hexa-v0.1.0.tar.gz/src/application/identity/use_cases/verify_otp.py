from shared.base.base_use_case import BaseUseCase
from application.identity.dtos import VerifyOTPRequest, AuthTokenResponse, UserResponse
from core.identity.ports.repos.user_repo import UserRepository
from core.identity.ports.repos.token_repo import TokenRepository
from core.identity.ports.services.auth_service import AuthService


class VerifyOTPUseCase(BaseUseCase[VerifyOTPRequest, AuthTokenResponse]):
    """Verify OTP code use case."""

    def __init__(
        self,
        user_repo: UserRepository,
        token_repo: TokenRepository,
        auth_service: AuthService,
    ):
        self.user_repo = user_repo
        self.token_repo = token_repo
        self.auth_service = auth_service

    async def execute(self, request: VerifyOTPRequest) -> AuthTokenResponse:
        """Execute OTP verification."""
        # Get stored OTP
        stored_otp = await self.token_repo.get_otp_code(request.email)
        if not stored_otp:
            raise ValueError("Invalid or expired OTP code")

        # Verify OTP
        if stored_otp != request.otp_code:
            raise ValueError("Invalid OTP code")

        # Get user
        user = await self.user_repo.get_by_email(request.email)
        if not user:
            raise ValueError("User not found")

        # Revoke OTP
        await self.token_repo.revoke_otp_code(request.email)

        # Generate tokens
        access_token, refresh_token = await self.auth_service.generate_tokens(user)

        # Store refresh token
        refresh_token_expires = 30 * 24 * 60 * 60  # 30 days in seconds
        await self.token_repo.store_refresh_token(
            user.id, refresh_token, refresh_token_expires
        )

        return AuthTokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_in=15 * 60,  # 15 minutes
            user=UserResponse(
                id=user.id,
                email=user.email,
                first_name=user.first_name,
                last_name=user.last_name,
                status=user.status,
                email_verified=user.email_verified,
                created_at=user.created_at,
                last_login_at=user.last_login_at,
            ),
        )
