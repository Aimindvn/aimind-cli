from datetime import datetime
from peewee import (
    CharField,
    BooleanField,
    DateTimeField,
    IntegerField,
)
from infra.db.db import BaseModel


class UserModel(BaseModel):
    """User Peewee model - Infrastructure layer entity."""

    email = CharField(unique=True, max_length=255)
    password_hash = CharField(null=True, max_length=255)
    first_name = CharField(max_length=100)
    last_name = CharField(max_length=100)
    status = CharField(max_length=20, default="pending")
    email_verified = BooleanField(default=False)
    email_verified_at = DateTimeField(null=True)
    last_login_at = DateTimeField(null=True)
    failed_login_attempts = IntegerField(default=0)
    locked_until = DateTimeField(null=True)

    class Meta:
        table_name = "users"
