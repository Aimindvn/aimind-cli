from core.identity.domains.account import Account
from shared.constants.auth_providers_enum import AuthProvider
from .account import AccountModel


class AccountMapper:
    """Mapper for converting between Account domain entity and AccountModel infrastructure entity."""

    @staticmethod
    def model_to_domain(model: AccountModel) -> Account:
        """Convert AccountModel to Account domain entity."""
        return Account(
            id=model.id,
            user_id=model.user_id,
            provider=AuthProvider(model.provider),
            provider_user_id=model.provider_user_id,
            provider_username=model.provider_username,
            provider_email=model.provider_email,
            access_token=model.access_token,
            refresh_token=model.refresh_token,
            expires_at=model.expires_at,
            token_type=model.token_type,
            scope=model.scope,
            provider_data=model.provider_data,
            created_at=model.created_at,
            updated_at=model.updated_at,
        )

    @staticmethod
    def domain_to_model_data(entity: Account) -> dict:
        """Convert Account domain entity to model data dictionary."""
        return {
            "id": entity.id,
            "user_id": entity.user_id,
            "provider": (
                entity.provider.value
                if isinstance(entity.provider, AuthProvider)
                else entity.provider
            ),
            "provider_user_id": entity.provider_user_id,
            "provider_username": entity.provider_username,
            "provider_email": entity.provider_email,
            "access_token": entity.access_token,
            "refresh_token": entity.refresh_token,
            "expires_at": entity.expires_at,
            "token_type": entity.token_type,
            "scope": entity.scope,
            "provider_data": entity.provider_data,
            "created_at": entity.created_at,
            "updated_at": entity.updated_at,
        }

    @staticmethod
    def update_model_from_domain(model: AccountModel, entity: Account) -> AccountModel:
        """Update AccountModel fields from Account domain entity."""
        model.user_id = entity.user_id
        model.provider = (
            entity.provider.value
            if isinstance(entity.provider, AuthProvider)
            else entity.provider
        )
        model.provider_user_id = entity.provider_user_id
        model.provider_username = entity.provider_username
        model.provider_email = entity.provider_email
        model.access_token = entity.access_token
        model.refresh_token = entity.refresh_token
        model.expires_at = entity.expires_at
        model.token_type = entity.token_type
        model.scope = entity.scope
        model.provider_data = entity.provider_data
        return model
