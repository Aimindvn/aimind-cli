# Infrastructure layer entities and mappers
