from datetime import datetime
from peewee import (
    CharField,
    TextField,
    DateTimeField,
    ForeignKeyField,
)
from playhouse.postgres_ext import JSONField
from infra.db.db import BaseModel
from .user import UserModel


class AccountModel(BaseModel):
    """Account Peewee model - Infrastructure layer entity."""

    user = ForeignKeyField(UserModel, backref="accounts", on_delete="CASCADE")
    provider = CharField(max_length=50)
    provider_user_id = CharField(max_length=255)
    provider_username = CharField(null=True, max_length=255)
    provider_email = CharField(null=True, max_length=255)
    access_token = TextField(null=True)
    refresh_token = TextField(null=True)
    expires_at = DateTimeField(null=True)
    token_type = CharField(max_length=50, default="Bearer")
    scope = CharField(null=True, max_length=500)
    provider_data = JSONField(default=dict)

    class Meta:
        table_name = "accounts"
        indexes = (("provider", "provider_user_id"), True)  # Unique constraint
