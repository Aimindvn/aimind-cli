from typing import Optional

from shared.base.base_repo_impl import BaseRepositoryImpl
from core.identity.ports.repos.user_repo import UserRepository
from core.identity.domains.user import User
from infra.auth.entities.user import UserModel
from infra.auth.entities.account import AccountModel
from infra.auth.entities.user_mapper import UserMapper
from infra.auth.entities.account_mapper import AccountMapper


class UserRepositoryImpl(BaseRepositoryImpl[User], UserRepository):
    """User repository implementation using Peewee and mappers."""

    def __init__(self):
        super().__init__(UserModel, User)
        self.user_mapper = UserMapper()
        self.account_mapper = AccountMapper()

    def _model_to_entity(self, model: UserModel) -> User:
        """Convert UserModel to User domain entity using mapper."""
        return self.user_mapper.model_to_domain(model)

    def _entity_to_model_data(self, entity: User) -> dict:
        """Convert User entity to model data using mapper."""
        return self.user_mapper.domain_to_model_data(entity)

    async def get_by_email(self, email: str) -> Optional[User]:
        """Get user by email address."""
        try:
            model = UserModel.get(UserModel.email == email)
            return self._model_to_entity(model)
        except UserModel.DoesNotExist:
            return None

    async def email_exists(self, email: str) -> bool:
        """Check if email already exists."""
        return UserModel.select().where(UserModel.email == email).exists()

    async def get_with_accounts(self, user_id: int) -> Optional[User]:
        """Get user with associated accounts."""
        try:
            user_model = UserModel.get_by_id(user_id)

            # Load associated accounts
            account_models = AccountModel.select().where(AccountModel.user == user_id)
            accounts = [
                self.account_mapper.model_to_domain(account_model)
                for account_model in account_models
            ]

            # Convert user with accounts
            user = self.user_mapper.model_to_domain(user_model, accounts)
            return user
        except UserModel.DoesNotExist:
            return None

    async def update(self, entity: User) -> User:
        """Update a user entity using mapper."""
        if not entity.id:
            raise ValueError("Entity must have an ID to update")

        try:
            # Get existing model
            model = UserModel.get_by_id(entity.id)

            # Update model using mapper
            updated_model = self.user_mapper.update_model_from_domain(model, entity)
            updated_model.save()

            return self._model_to_entity(updated_model)
        except UserModel.DoesNotExist:
            raise ValueError(f"User with ID {entity.id} not found")
