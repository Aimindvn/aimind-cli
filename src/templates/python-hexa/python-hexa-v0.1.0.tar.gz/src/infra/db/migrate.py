#!/usr/bin/env python3
"""Database migration CLI tool.

Usage:
    python migrate.py create <name>           Create a new migration
    python migrate.py apply [migration_name]   Apply migrations
    python migrate.py rollback [count]         Rollback migrations (default: 1)
    python migrate.py list                     List all migrations
    python migrate.py status                   Show migration status
"""

import sys
import asyncio
from pathlib import Path

# Add src to path for imports
src_path = Path(__file__).parent.parent.parent
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))

from infra.db.migration import MigrationManager
from infra.db.db import connect_db, disconnect_db, create_migration_table
from shared.settings import get_settings


class MigrationCLI:
    """CLI interface for database migrations."""

    def __init__(self):
        """Initialize the CLI."""
        self.settings = get_settings()
        migrations_dir = Path(__file__).parent / "migrations"
        self.manager = MigrationManager(migrations_dir)

    def print_header(self):
        """Print header information."""
        print(f"\n📦 Database Migration Manager - {self.settings.database_name}")
        print("=" * 60)

    def print_footer(self):
        """Print footer."""
        print("=" * 60)

    async def create_command(self, args: list):
        """Create a new migration file.

        Args:
            args: Command arguments [migration_name]
        """
        if not args:
            print("✗ Error: Migration name required")
            print("Usage: python migrate.py create <name>")
            return False

        migration_name = args[0]

        # Validate migration name
        if not migration_name.replace("_", "").replace("-", "").isalnum():
            print("✗ Error: Migration name must be alphanumeric with underscores")
            return False

        try:
            file_path = self.manager.create_migration(migration_name)
            print(f"\n✓ Migration created: {Path(file_path).name}")
            print(f"  Path: {file_path}")
            print(f"\n  Edit the migration file and implement up() and down() methods")
            return True
        except Exception as e:
            print(f"✗ Error creating migration: {e}")
            return False

    async def apply_command(self, args: list):
        """Apply pending migrations.

        Args:
            args: Optional specific migration to apply
        """
        try:
            connect_db()
            create_migration_table()

            migration_names = args if args else None

            print(f"\n📋 Applying migrations...")
            await self.manager.apply_migrations(migration_names)
            print(f"\n✓ Migrations applied successfully")
            return True
        except Exception as e:
            print(f"✗ Error applying migrations: {e}")
            return False
        finally:
            disconnect_db()

    async def rollback_command(self, args: list):
        """Rollback migrations.

        Args:
            args: Optional number of migrations to rollback (default: 1)
        """
        try:
            count = 1
            if args:
                try:
                    count = int(args[0])
                    if count < 1:
                        raise ValueError("Count must be >= 1")
                except ValueError as e:
                    print(f"✗ Error: Invalid count - {e}")
                    return False

            print(f"\n⏮️  Rolling back {count} migration(s)...")
            await self.manager.rollback_migrations(count)
            print(f"\n✓ Migrations rolled back successfully")
            return True
        except Exception as e:
            print(f"✗ Error rolling back migrations: {e}")
            return False
        finally:
            disconnect_db()

    def list_command(self, args: list):
        """List all migrations.

        Args:
            args: Unused
        """
        try:
            self.manager.list_migrations()
            return True
        except Exception as e:
            print(f"✗ Error listing migrations: {e}")
            return False

    def status_command(self, args: list):
        """Show migration status.

        Args:
            args: Unused
        """
        try:
            connect_db()
            create_migration_table()

            applied = self.manager.get_applied_migrations()
            pending = self.manager.get_pending_migrations()
            total = len(applied) + len(pending)

            print(f"\n📊 Migration Status")
            print(f"  Total migrations: {total}")
            print(f"  Applied: {len(applied)} ✓")
            print(f"  Pending: {len(pending)} ○")

            if applied:
                print(f"\n  Applied migrations:")
                for m in sorted(applied):
                    print(f"    ✓ {m}")

            if pending:
                print(f"\n  Pending migrations:")
                for m in sorted(pending):
                    print(f"    ○ {m}")

            return True
        except Exception as e:
            print(f"✗ Error getting migration status: {e}")
            return False
        finally:
            disconnect_db()

    def print_help(self):
        """Print help message."""
        print(
            """
Database Migration Tool

Commands:
  create <name>           Create a new migration file
                         Example: python migrate.py create add_user_index
  
  apply [migration_name]  Apply pending migrations
                         Example: python migrate.py apply
                         Example: python migrate.py apply 001_create_users_table
  
  rollback [count]        Rollback migrations (default: 1)
                         Example: python migrate.py rollback
                         Example: python migrate.py rollback 2
  
  list                    List all migrations with status
                         Example: python migrate.py list
  
  status                  Show migration status
                         Example: python migrate.py status
  
  help                    Show this help message

Examples:
  # Create a new migration
  python migrate.py create add_email_timestamp
  
  # Apply all pending migrations
  python migrate.py apply
  
  # Rollback last migration
  python migrate.py rollback
  
  # Rollback last 3 migrations
  python migrate.py rollback 3
  
  # List migrations
  python migrate.py list
"""
        )

    async def run(self, args: list = None):
        """Run the migration CLI.

        Args:
            args: Command line arguments
        """
        if args is None:
            args = sys.argv[1:]

        self.print_header()

        if not args or args[0] == "help":
            self.print_help()
            self.print_footer()
            return True

        command = args[0].lower()
        command_args = args[1:]

        result = False

        if command == "create":
            result = await self.create_command(command_args)
        elif command in ("apply", "up"):
            result = await self.apply_command(command_args)
        elif command in ("rollback", "down"):
            result = await self.rollback_command(command_args)
        elif command == "list":
            result = self.list_command(command_args)
        elif command == "status":
            result = self.status_command(command_args)
        else:
            print(f"✗ Unknown command: {command}")
            print(f"\nUse 'python migrate.py help' for available commands")
            result = False

        self.print_footer()
        return result


async def main():
    """Main entry point."""
    cli = MigrationCLI()
    success = await cli.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    asyncio.run(main())
