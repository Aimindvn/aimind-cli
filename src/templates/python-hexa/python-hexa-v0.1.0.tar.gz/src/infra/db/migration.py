"""Migration system for managing database schema changes."""

from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
import importlib
from typing import List, Optional
import sys

from infra.db.db import db, MigrationModel, connect_db, disconnect_db


class Migration(ABC):
    """Base class for all migrations."""

    @property
    def name(self) -> str:
        """Get migration name from class name."""
        return self.__class__.__name__

    @abstractmethod
    async def up(self):
        """Apply the migration (upgrade schema)."""
        pass

    @abstractmethod
    async def down(self):
        """Rollback the migration (downgrade schema)."""
        pass


class MigrationManager:
    """Manager for running and tracking database migrations."""

    def __init__(self, migrations_dir: Path = None):
        """Initialize migration manager.

        Args:
            migrations_dir: Directory containing migration files
        """
        if migrations_dir is None:
            migrations_dir = Path(__file__).parent / "migrations"

        self.migrations_dir = migrations_dir
        self.migrations_dir.mkdir(exist_ok=True)

    def _load_migration(self, migration_name: str) -> Optional[Migration]:
        """Load a migration class by name.

        Args:
            migration_name: Name of the migration (file name without .py)

        Returns:
            Migration instance or None if not found
        """
        migration_file = self.migrations_dir / f"{migration_name}.py"

        if not migration_file.exists():
            return None

        try:
            # Load the migration module
            spec = importlib.util.spec_from_file_location(
                migration_name, migration_file
            )
            module = importlib.util.module_from_spec(spec)
            sys.modules[migration_name] = module
            spec.loader.exec_module(module)

            # Find the Migration subclass
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (
                    isinstance(attr, type)
                    and issubclass(attr, Migration)
                    and attr is not Migration
                ):
                    return attr()
        except Exception as e:
            print(f"Error loading migration {migration_name}: {e}")
            return None

        return None

    def create_migration(self, migration_name: str) -> str:
        """Create a new migration file template.

        Args:
            migration_name: Name for the migration (without timestamp)

        Returns:
            Path to the created migration file
        """
        timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
        file_name = f"{timestamp}_{migration_name}"
        migration_file = self.migrations_dir / f"{file_name}.py"

        template = '''"""Migration: {migration_name}."""

from infra.db.migration import Migration
from infra.db.db import db


class {class_name}(Migration):
    """Migration for {migration_name}."""

    async def up(self):
        """Apply the migration.
        
        Add your schema changes here using peewee or raw SQL.
        Example:
            with db.execute_sql('ALTER TABLE users ADD COLUMN new_field VARCHAR(100);'):
                pass
        """
        pass

    async def down(self):
        """Rollback the migration.
        
        Add rollback logic here.
        Example:
            with db.execute_sql('ALTER TABLE users DROP COLUMN new_field;'):
                pass
        """
        pass
'''

        # Convert snake_case to CamelCase for class name
        class_name = "".join(word.capitalize() for word in migration_name.split("_"))

        content = template.format(migration_name=migration_name, class_name=class_name)

        migration_file.write_text(content)
        return str(migration_file)

    def get_applied_migrations(self) -> List[str]:
        """Get list of applied migrations.

        Returns:
            List of migration names that have been applied
        """
        try:
            return [m.name for m in MigrationModel.select()]
        except Exception:
            # Table might not exist yet
            return []

    def get_pending_migrations(self) -> List[str]:
        """Get list of pending migrations.

        Returns:
            List of migration names that have not been applied
        """
        applied = self.get_applied_migrations()
        all_migrations = sorted(
            [
                f.stem
                for f in self.migrations_dir.glob("*.py")
                if f.name != "__init__.py"
            ]
        )
        return [m for m in all_migrations if m not in applied]

    async def apply_migrations(self, migration_names: List[str] = None):
        """Apply pending migrations.

        Args:
            migration_names: Specific migrations to apply, or None for all pending

        Raises:
            Exception: If migration fails or migration not found
        """
        connect_db()

        try:
            # Create migration tracking table if it doesn't exist
            MigrationModel.create_table(safe=True)

            if migration_names is None:
                migration_names = self.get_pending_migrations()

            if not migration_names:
                print("✓ No pending migrations")
                return

            for migration_name in migration_names:
                print(f"Applying migration: {migration_name}...", end=" ")

                migration = self._load_migration(migration_name)
                if not migration:
                    raise FileNotFoundError(f"Migration '{migration_name}' not found")

                try:
                    # Apply the migration
                    await migration.up()

                    # Record the migration
                    MigrationModel.create(name=migration_name)
                    print("✓ Applied")
                except Exception as e:
                    print(f"✗ Failed: {e}")
                    raise
        finally:
            disconnect_db()

    async def rollback_migrations(self, count: int = 1):
        """Rollback the last N migrations.

        Args:
            count: Number of migrations to rollback

        Raises:
            Exception: If rollback fails
        """
        connect_db()

        try:
            # Get the last N applied migrations in reverse order
            applied = sorted(self.get_applied_migrations(), reverse=True)[:count]

            if not applied:
                print("✓ No migrations to rollback")
                return

            for migration_name in applied:
                print(f"Rolling back migration: {migration_name}...", end=" ")

                migration = self._load_migration(migration_name)
                if not migration:
                    print(f"✗ Migration not found")
                    continue

                try:
                    # Rollback the migration
                    await migration.down()

                    # Remove the migration record
                    MigrationModel.delete().where(
                        MigrationModel.name == migration_name
                    ).execute()
                    print("✓ Rolled back")
                except Exception as e:
                    print(f"✗ Failed: {e}")
                    raise
        finally:
            disconnect_db()

    def list_migrations(self) -> None:
        """List all migrations with their status."""
        connect_db()

        try:
            # Create migration tracking table if it doesn't exist
            MigrationModel.create_table(safe=True)

            applied = set(self.get_applied_migrations())
            all_migrations = sorted(
                [
                    f.stem
                    for f in self.migrations_dir.glob("*.py")
                    if f.name != "__init__.py"
                ]
            )

            if not all_migrations:
                print("No migrations found")
                return

            print("\nMigrations:")
            print("-" * 60)
            print(f"{'Name':<45} {'Status':<15}")
            print("-" * 60)

            for migration_name in all_migrations:
                status = "✓ Applied" if migration_name in applied else "○ Pending"
                print(f"{migration_name:<45} {status:<15}")

            print("-" * 60)
        finally:
            disconnect_db()
