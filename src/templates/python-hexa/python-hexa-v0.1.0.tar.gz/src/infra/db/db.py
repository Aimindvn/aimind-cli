from datetime import datetime
import peewee
from playhouse.postgres_ext import PostgresqlExtDatabase
from shared.settings import get_settings

settings = get_settings()

# Database connection
db = PostgresqlExtDatabase(
    settings.database_name,
    user=settings.database_user,
    password=settings.database_password,
    host=settings.database_host,
    port=settings.database_port,
)


class BaseModel(peewee.Model):
    """Base model class."""

    id = peewee.IntegerField(primary_key=True)
    created_at = peewee.DateTimeField(default=datetime.utcnow)
    updated_at = peewee.DateTimeField(default=datetime.utcnow)

    class Meta:
        database = db

    def save(self, *args, **kwargs):
        """Override save to update timestamp."""
        self.updated_at = datetime.utcnow()
        return super().save(*args, **kwargs)


class MigrationModel(peewee.Model):
    """Migration tracking table."""

    name = peewee.CharField(unique=True, max_length=255)
    applied_at = peewee.DateTimeField(default=datetime.utcnow)

    class Meta:
        table_name = "migrations"
        database = db


# Database connection management
def connect_db():
    """Connect to database."""
    db.connect()


def disconnect_db():
    """Disconnect from database."""
    if not db.is_closed():
        db.close()


def create_tables():
    """Create database tables."""
    from infra.auth.entities.user import UserModel
    from infra.auth.entities.account import AccountModel

    with db:
        # Create migrations table first
        db.create_tables([MigrationModel, UserModel, AccountModel])


def create_migration_table():
    """Create only the migration tracking table."""
    with db:
        db.create_tables([MigrationModel])
