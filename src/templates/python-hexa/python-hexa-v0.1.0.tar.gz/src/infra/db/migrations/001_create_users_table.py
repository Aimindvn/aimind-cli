"""Migration: Create users table."""

from infra.db.migration import Migration
from infra.db.db import db


class CreateUsersTable(Migration):
    """Create the users table."""

    async def up(self):
        """Create users table."""
        db.execute_sql(
            """
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                email VARCHAR(255) UNIQUE NOT NULL,
                password_hash VARCHAR(255),
                first_name VARCHAR(100) NOT NULL,
                last_name VARCHAR(100) NOT NULL,
                status VARCHAR(20) DEFAULT 'pending',
                email_verified BOOLEAN DEFAULT FALSE,
                email_verified_at TIMESTAMP NULL,
                last_login_at TIMESTAMP NULL,
                failed_login_attempts INTEGER DEFAULT 0,
                locked_until TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )

    async def down(self):
        """Drop users table."""
        db.execute_sql("DROP TABLE IF EXISTS users")
