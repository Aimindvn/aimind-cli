import redis.asyncio as redis
from typing import Optional
from shared.settings import get_settings

settings = get_settings()

# Redis connection
redis_client = redis.Redis(
    host=settings.redis_host,
    port=settings.redis_port,
    password=settings.redis_password,
    db=settings.redis_db,
    decode_responses=True,
)


class RedisConnection:
    """Redis connection manager."""

    @staticmethod
    async def get_client():
        """Get Redis client."""
        return redis_client

    @staticmethod
    async def close():
        """Close Redis connection."""
        await redis_client.close()
