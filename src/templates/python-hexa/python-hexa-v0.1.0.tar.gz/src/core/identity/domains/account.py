from datetime import datetime
from typing import Optional, Dict, Any
from dataclasses import dataclass, field

from shared.base.base_entity import BaseEntity
from shared.constants.auth_providers_enum import AuthProvider


@dataclass
class Account(BaseEntity):
    """External account domain entity for OAuth providers."""

    user_id: int = 0
    provider: AuthProvider = AuthProvider.EMAIL
    provider_user_id: str = ""
    provider_username: Optional[str] = None
    provider_email: Optional[str] = None
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    expires_at: Optional[datetime] = None
    token_type: str = "Bearer"
    scope: Optional[str] = None
    provider_data: Dict[str, Any] = field(default_factory=dict)

    def is_token_valid(self) -> bool:
        """Check if access token is still valid."""
        if not self.access_token:
            return False
        if not self.expires_at:
            return True
        return datetime.utcnow() < self.expires_at

    def update_tokens(
        self,
        access_token: str,
        refresh_token: Optional[str] = None,
        expires_at: Optional[datetime] = None,
    ) -> None:
        """Update account tokens."""
        self.access_token = access_token
        if refresh_token:
            self.refresh_token = refresh_token
        if expires_at:
            self.expires_at = expires_at
        self.updated_at = datetime.utcnow()
