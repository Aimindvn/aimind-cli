from datetime import datetime
from typing import Optional, List
from dataclasses import dataclass, field
from passlib.context import CryptContext

from shared.base.base_entity import BaseEntity
from shared.constants.auth_providers_enum import UserStatus, AuthProvider


@dataclass
class User(BaseEntity):
    """User domain entity."""

    email: str = ""
    password_hash: Optional[str] = None
    first_name: str = ""
    last_name: str = ""
    status: UserStatus = UserStatus.PENDING
    email_verified: bool = False
    email_verified_at: Optional[datetime] = None
    last_login_at: Optional[datetime] = None
    failed_login_attempts: int = 0
    locked_until: Optional[datetime] = None
    accounts: List["Account"] = field(default_factory=list)

    # Password context for hashing
    _pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

    # bcrypt has a maximum password length of 72 bytes
    MAX_PASSWORD_LENGTH = 72

    def set_password(self, password: str) -> None:
        """Hash and set user password.

        Args:
            password: Plain text password to hash

        Raises:
            ValueError: If password exceeds 72 bytes (bcrypt limit)
        """
        if isinstance(password, str):
            password_bytes = password.encode("utf-8")
        else:
            password_bytes = password

        if len(password_bytes) > self.MAX_PASSWORD_LENGTH:
            raise ValueError(
                f"Password cannot be longer than {self.MAX_PASSWORD_LENGTH} bytes. "
                f"Current length: {len(password_bytes)} bytes."
            )

        self.password_hash = self._pwd_context.hash(password)

    def verify_password(self, password: str) -> bool:
        """Verify password against hash."""
        if not self.password_hash:
            return False
        return self._pwd_context.verify(password, self.password_hash)

    def can_login(self) -> bool:
        """Check if user can login."""
        if self.status != UserStatus.ACTIVE:
            return False
        if self.locked_until and self.locked_until > datetime.utcnow():
            return False
        return True

    def verify_email(self) -> None:
        """Mark email as verified."""
        self.email_verified = True
        self.email_verified_at = datetime.utcnow()
        if self.status == UserStatus.PENDING:
            self.status = UserStatus.ACTIVE

    def record_failed_login(self, max_attempts: int = 5) -> None:
        """Record failed login attempt and lock if needed."""
        self.failed_login_attempts += 1
        if self.failed_login_attempts >= max_attempts:
            # Lock for 30 minutes
            self.locked_until = datetime.utcnow().replace(
                minute=datetime.utcnow().minute + 30
            )

    def record_successful_login(self) -> None:
        """Record successful login."""
        self.last_login_at = datetime.utcnow()
        self.failed_login_attempts = 0
        self.locked_until = None

    def get_full_name(self) -> str:
        """Get user's full name."""
        return f"{self.first_name} {self.last_name}".strip()
