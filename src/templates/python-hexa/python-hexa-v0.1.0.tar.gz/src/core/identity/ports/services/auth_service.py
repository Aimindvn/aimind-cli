from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, Tuple
from datetime import timedelta

from core.identity.domains.user import User
from core.identity.value_objects import AuthToken
from shared.constants.auth_providers_enum import TokenType, AuthProvider


class AuthService(ABC):
    """Authentication service port interface."""

    @abstractmethod
    async def generate_tokens(self, user: User) -> Tuple[str, str]:
        """Generate access and refresh tokens for user."""
        pass

    @abstractmethod
    async def verify_access_token(self, token: str) -> Optional[Dict[str, Any]]:
        """Verify and decode access token."""
        pass

    @abstractmethod
    async def generate_email_token(
        self, email: str, token_type: TokenType, expires_in: timedelta
    ) -> str:
        """Generate token for email verification or password reset."""
        pass

    @abstractmethod
    async def verify_email_token(
        self, token: str, token_type: TokenType
    ) -> Optional[str]:
        """Verify email token and return email if valid."""
        pass

    @abstractmethod
    async def generate_otp_code(self, email: str) -> str:
        """Generate OTP code for email."""
        pass


class OAuthService(ABC):
    """OAuth service port interface."""

    @abstractmethod
    async def get_authorization_url(
        self, provider: AuthProvider, redirect_uri: str, state: str
    ) -> str:
        """Get OAuth authorization URL."""
        pass

    @abstractmethod
    async def exchange_code_for_tokens(
        self,
        provider: AuthProvider,
        code: str,
        redirect_uri: str,
        state: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Exchange authorization code for tokens."""
        pass

    @abstractmethod
    async def get_user_info(
        self, provider: AuthProvider, access_token: str
    ) -> Dict[str, Any]:
        """Get user information from OAuth provider."""
        pass
