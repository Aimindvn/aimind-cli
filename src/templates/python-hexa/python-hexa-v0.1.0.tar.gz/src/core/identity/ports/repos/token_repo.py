from abc import ABC, abstractmethod
from typing import Optional


class TokenRepository(ABC):
    """Token repository interface for managing tokens in Redis."""

    @abstractmethod
    async def store_refresh_token(
        self, user_id: int, token: str, expires_in: int
    ) -> None:
        """Store refresh token in Redis."""
        pass

    @abstractmethod
    async def get_refresh_token(self, token: str) -> Optional[int]:
        """Get user ID by refresh token."""
        pass

    @abstractmethod
    async def revoke_refresh_token(self, token: str) -> bool:
        """Revoke refresh token."""
        pass

    @abstractmethod
    async def store_email_token(self, email: str, token: str, expires_in: int) -> None:
        """Store email verification/reset token."""
        pass

    @abstractmethod
    async def get_email_token(self, token: str) -> Optional[str]:
        """Get email by token."""
        pass

    @abstractmethod
    async def revoke_email_token(self, token: str) -> bool:
        """Revoke email token."""
        pass

    @abstractmethod
    async def store_otp_code(self, email: str, code: str, expires_in: int) -> None:
        """Store OTP code for email."""
        pass

    @abstractmethod
    async def get_otp_code(self, email: str) -> Optional[str]:
        """Get OTP code for email."""
        pass

    @abstractmethod
    async def revoke_otp_code(self, email: str) -> bool:
        """Revoke OTP code for email."""
        pass
