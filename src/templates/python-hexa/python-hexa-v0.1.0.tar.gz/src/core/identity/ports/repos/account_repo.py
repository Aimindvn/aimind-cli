from abc import abstractmethod
from typing import Optional, List

from shared.base.base_repo import BaseRepository
from core.identity.domains.account import Account
from shared.constants.auth_providers_enum import AuthProvider


class AccountRepository(BaseRepository[Account]):
    """Account repository interface."""

    @abstractmethod
    async def get_by_provider_and_user_id(
        self, provider: AuthProvider, provider_user_id: str
    ) -> Optional[Account]:
        """Get account by provider and provider user ID."""
        pass

    @abstractmethod
    async def get_by_user_id(self, user_id: int) -> List[Account]:
        """Get all accounts for a user."""
        pass

    @abstractmethod
    async def get_by_provider_and_email(
        self, provider: AuthProvider, email: str
    ) -> Optional[Account]:
        """Get account by provider and email."""
        pass
