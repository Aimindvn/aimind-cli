from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException

from interfaces.api.responses.exception_handler import (
    validation_exception_handler,
    value_exception_handler,
    http_exception_handler,
    general_exception_handler,
)
from interfaces.api.routes.identity_route import router as identity_router
from bootstrap.container import Container
from shared.settings import get_settings


def create_app() -> FastAPI:
    """Create and configure FastAPI application."""
    settings = get_settings()

    # Create FastAPI app
    app = FastAPI(
        title=settings.app_name,
        description="Hexagonal architecture Python template with authentication",
        version="1.0.0",
        debug=settings.debug,
    )

    # Configure CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"] if settings.debug else [settings.frontend_url],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Setup dependency injection
    container = Container()
    container.wire(
        modules=[
            "interfaces.api.routes.identity_route",
        ]
    )
    app.container = container

    # Add exception handlers
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    app.add_exception_handler(ValueError, value_exception_handler)
    app.add_exception_handler(HTTPException, http_exception_handler)
    app.add_exception_handler(Exception, general_exception_handler)

    # Include routers
    app.include_router(identity_router, prefix="/api")

    # Health check endpoint
    @app.get("/health")
    async def health_check():
        return {"status": "healthy", "message": "API is running"}

    return app
