from fastapi import APIRouter, Depends, HTTPException, status
from dependency_injector.wiring import inject, Provide

from application.identity.dtos import (
    RegisterRequest,
    LoginRequest,
    RefreshTokenRequest,
    VerifyEmailRequest,
    ForgotPasswordRequest,
    ResetPasswordRequest,
    VerifyOTPRequest,
    AuthTokenResponse,
    UserResponse,
    MessageResponse,
)
from application.identity.use_cases.register_user import RegisterUserUseCase
from application.identity.use_cases.login_user import LoginUserUseCase
from application.identity.use_cases.verify_email import VerifyEmailUseCase
from application.identity.use_cases.forgot_password import ForgotPasswordUseCase
from application.identity.use_cases.reset_password import ResetPasswordUseCase
from application.identity.use_cases.generate_otp import GenerateOTPUseCase
from application.identity.use_cases.verify_otp import VerifyOTPUseCase
from application.identity.use_cases.refresh_token import RefreshTokenUseCase
from bootstrap.container import Container
from interfaces.api.responses.response_model import APIResponse

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", response_model=APIResponse)
@inject
async def register(
    request: RegisterRequest,
    use_case: RegisterUserUseCase = Depends(Provide[Container.register_user_use_case]),
) -> APIResponse:
    """Register a new user."""
    try:
        user = await use_case.execute(request)
        return APIResponse(
            message="Registration successful. Please check your email for verification.",
            data=user,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post("/login", response_model=APIResponse)
@inject
async def login(
    request: LoginRequest,
    use_case: LoginUserUseCase = Depends(Provide[Container.login_user_use_case]),
) -> APIResponse:
    """User login."""
    try:
        auth_response = await use_case.execute(request)
        return APIResponse(message="Login successful", data=auth_response)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(e))


@router.post("/refresh", response_model=APIResponse)
@inject
async def refresh_token(
    request: RefreshTokenRequest,
    use_case: RefreshTokenUseCase = Depends(Provide[Container.refresh_token_use_case]),
) -> APIResponse:
    """Refresh access token."""
    try:
        auth_response = await use_case.execute(request)
        return APIResponse(message="Token refreshed successfully", data=auth_response)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail=str(e))


@router.post("/verify-email", response_model=APIResponse)
@inject
async def verify_email(
    request: VerifyEmailRequest,
    use_case: VerifyEmailUseCase = Depends(Provide[Container.verify_email_use_case]),
) -> APIResponse:
    """Verify email address."""
    try:
        response = await use_case.execute(request)
        return APIResponse(message=response.message)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post("/forgot-password", response_model=APIResponse)
@inject
async def forgot_password(
    request: ForgotPasswordRequest,
    use_case: ForgotPasswordUseCase = Depends(
        Provide[Container.forgot_password_use_case]
    ),
) -> APIResponse:
    """Request password reset."""
    response = await use_case.execute(request)
    return APIResponse(message=response.message)


@router.post("/reset-password", response_model=APIResponse)
@inject
async def reset_password(
    request: ResetPasswordRequest,
    use_case: ResetPasswordUseCase = Depends(
        Provide[Container.reset_password_use_case]
    ),
) -> APIResponse:
    """Reset password using token."""
    try:
        response = await use_case.execute(request)
        return APIResponse(message=response.message)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post("/generate-otp", response_model=APIResponse)
@inject
async def generate_otp(
    request: ForgotPasswordRequest,
    use_case: GenerateOTPUseCase = Depends(Provide[Container.generate_otp_use_case]),
) -> APIResponse:
    """Generate and send OTP code."""
    response = await use_case.execute(request)
    return APIResponse(message=response.message)


@router.post("/verify-otp", response_model=APIResponse)
@inject
async def verify_otp(
    request: VerifyOTPRequest,
    use_case: VerifyOTPUseCase = Depends(Provide[Container.verify_otp_use_case]),
) -> APIResponse:
    """Verify OTP code and login."""
    try:
        auth_response = await use_case.execute(request)
        return APIResponse(message="OTP verified successfully", data=auth_response)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
