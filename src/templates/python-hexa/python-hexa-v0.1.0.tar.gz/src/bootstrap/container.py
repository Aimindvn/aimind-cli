from dependency_injector import containers, providers
from dependency_injector.wiring import Provide

# Domain and Infrastructure imports
from infra.auth.repos.user_repo_impl import UserRepositoryImpl
from infra.auth.repos.account_repo_impl import AccountRepositoryImpl
from infra.auth.repos.token_repo_impl import TokenRepositoryImpl
from infra.auth.services.auth_service_impl import AuthServiceImpl
from infra.email.smtp_service import SMTPEmailService

# Use case imports
from application.identity.use_cases.register_user import RegisterUserUseCase
from application.identity.use_cases.login_user import LoginUserUseCase
from application.identity.use_cases.verify_email import VerifyEmailUseCase
from application.identity.use_cases.forgot_password import ForgotPasswordUseCase
from application.identity.use_cases.reset_password import ResetPasswordUseCase
from application.identity.use_cases.generate_otp import GenerateOTPUseCase
from application.identity.use_cases.verify_otp import VerifyOTPUseCase
from application.identity.use_cases.refresh_token import RefreshTokenUseCase

from shared.settings import get_settings


class Container(containers.DeclarativeContainer):
    """Dependency injection container."""

    # Configuration
    config = providers.Configuration()
    settings = providers.Singleton(get_settings)

    # Repositories
    user_repository = providers.Singleton(UserRepositoryImpl)
    account_repository = providers.Singleton(AccountRepositoryImpl)
    token_repository = providers.Singleton(TokenRepositoryImpl)

    # Services
    auth_service = providers.Singleton(AuthServiceImpl)
    email_service = providers.Singleton(SMTPEmailService)

    # Use Cases
    register_user_use_case = providers.Factory(
        RegisterUserUseCase,
        user_repo=user_repository,
        auth_service=auth_service,
        email_service=email_service,
    )

    login_user_use_case = providers.Factory(
        LoginUserUseCase,
        user_repo=user_repository,
        token_repo=token_repository,
        auth_service=auth_service,
    )

    verify_email_use_case = providers.Factory(
        VerifyEmailUseCase,
        user_repo=user_repository,
        auth_service=auth_service,
        email_service=email_service,
    )

    forgot_password_use_case = providers.Factory(
        ForgotPasswordUseCase,
        user_repo=user_repository,
        auth_service=auth_service,
        email_service=email_service,
    )

    reset_password_use_case = providers.Factory(
        ResetPasswordUseCase,
        user_repo=user_repository,
        auth_service=auth_service,
    )

    generate_otp_use_case = providers.Factory(
        GenerateOTPUseCase,
        user_repo=user_repository,
        token_repo=token_repository,
        auth_service=auth_service,
        email_service=email_service,
    )

    verify_otp_use_case = providers.Factory(
        VerifyOTPUseCase,
        user_repo=user_repository,
        token_repo=token_repository,
        auth_service=auth_service,
    )

    refresh_token_use_case = providers.Factory(
        RefreshTokenUseCase,
        user_repo=user_repository,
        token_repo=token_repository,
        auth_service=auth_service,
    )
