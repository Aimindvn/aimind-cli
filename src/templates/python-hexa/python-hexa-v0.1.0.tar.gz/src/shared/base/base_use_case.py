from abc import ABC, abstractmethod
from typing import TypeVar, Generic

Request = TypeVar("Request")
Response = TypeVar("Response")


class BaseUseCase(ABC, Generic[Request, Response]):
    """Base use case class."""

    @abstractmethod
    async def execute(self, request: Request) -> Response:
        """Execute the use case."""
        pass
