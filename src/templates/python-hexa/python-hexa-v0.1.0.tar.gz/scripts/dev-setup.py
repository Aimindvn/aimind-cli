#!/usr/bin/env python3
"""Development setup script."""

import subprocess
import sys
import os
from pathlib import Path


def run_command(command: str, cwd: Path = None) -> bool:
    """Run a command and return success status."""
    print(f"Running: {command}")
    try:
        result = subprocess.run(
            command.split(), cwd=cwd, check=True, capture_output=True, text=True
        )
        print(result.stdout)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")
        print(f"stderr: {e.stderr}")
        return False


def main():
    """Setup development environment."""
    project_root = Path(__file__).parent.parent

    print("🚀 Setting up development environment...")

    # Check if .env exists, create from example if not
    env_file = project_root / ".env"
    env_example = project_root / ".env.example"

    if not env_file.exists() and env_example.exists():
        print("📝 Creating .env file from .env.example")
        with open(env_example) as f:
            content = f.read()
        with open(env_file, "w") as f:
            f.write(content)

    # Create virtual environment
    print("🐍 Creating virtual environment with uv...")
    if not run_command("uv venv", project_root):
        print("❌ Failed to create virtual environment")
        return False

    # Install dependencies
    print("📦 Installing dependencies...")
    if not run_command("uv pip install -r pyproject.toml", project_root):
        print("❌ Failed to install dependencies")
        return False

    # Install dev dependencies
    print("🛠️ Installing development dependencies...")
    if not run_command("uv pip install -e .[dev]", project_root):
        print("❌ Failed to install dev dependencies")
        return False

    # Run database migration
    print("🗄️ Setting up database...")
    # Note: This requires PostgreSQL to be running
    # You might want to run this manually or with Docker

    print("✅ Development environment setup complete!")
    print("\n🚀 To start the development server:")
    print(
        "   1. Activate virtual environment: source .venv/bin/activate (Linux/Mac) or .venv\\Scripts\\activate (Windows)"
    )
    print(
        "   2. Start services with Docker: docker-compose -f docker/docker-compose.yml up -d postgres redis mailhog"
    )
    print("   3. Run migrations: python src/infra/db/migrate.py")
    print("   4. Start server: python src/main.py")
    print("   5. Run tests: pytest")

    return True


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
