# AIMind Python Template

A comprehensive Python template project implementing **Hexagonal Architecture** (Clean Architecture) with modern authentication features.

## 🏗️ Architecture

This template follows **Hexagonal Architecture** principles with clear separation of concerns:

- **Core/Domain**: Business logic and domain entities (`src/core/`)
- **Application**: Use cases and application services (`src/application/`)
- **Infrastructure**: External adapters (database, email, etc.) (`src/infra/`)
- **Interfaces**: API controllers and external interfaces (`src/interfaces/`)
- **Bootstrap**: Dependency injection and configuration (`src/bootstrap/`)

## ✨ Features

### 🔐 Authentication System
- **Multi-provider authentication** with AuthLib support (Google, GitHub, Microsoft, Facebook)
- **Email verification** with secure token-based verification
- **Password reset** with time-limited tokens
- **OTP verification** for enhanced security (6-digit codes via email)
- **Refresh token management** with Redis storage
- **Account lockout** protection against brute force attacks
- **JWT-based authentication** with configurable expiration

### 🛠️ Technical Stack
- **FastAPI** - High-performance async web framework
- **Peewee ORM** - Lightweight, expressive ORM for database operations
- **Redis** - Session management and token storage
- **Bcrypt** - Secure password hashing
- **Pytest** - Comprehensive test framework with async support
- **Dependency Injector** - Clean dependency injection
- **Pydantic** - Data validation and serialization
- **Docker** - Containerized development environment

### 📧 Email Features
- **SMTP integration** with template-based emails
- **Email templates** for verification, password reset, OTP, and welcome messages
- **MailHog integration** for development email testing

## 🚀 Quick Start

### Prerequisites
- Python 3.12+
- PostgreSQL
- Redis
- uv (recommended for package management)

### Setup

1. **Clone and setup environment:**
   ```bash
   git clone <your-repo>
   cd aimind-python-template
   python scripts/dev-setup.py
   ```

2. **Configure environment:**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Start services with Docker:**
   ```bash
   docker-compose -f docker/docker-compose.yml up -d postgres redis mailhog
   ```

4. **Run database migrations:**
   ```bash
   python src/infra/db/migrate.py
   ```

5. **Start the development server:**
   ```bash
   python src/main.py
   ```

## 📚 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `POST /api/auth/refresh` - Refresh access token
- `POST /api/auth/verify-email` - Verify email address
- `POST /api/auth/forgot-password` - Request password reset
- `POST /api/auth/reset-password` - Reset password with token
- `POST /api/auth/generate-otp` - Generate OTP code
- `POST /api/auth/verify-otp` - Verify OTP and login

### Health Check
- `GET /health` - Service health status

## 🧪 Testing

Run the comprehensive test suite:

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=src --cov-report=html

# Run specific test categories
pytest -m unit
pytest -m integration
pytest -m auth
```

## 🔧 Configuration

Key environment variables in `.env`:

```bash
# Database
DATABASE_HOST=localhost
DATABASE_NAME=aimind_template
DATABASE_USER=postgres
DATABASE_PASSWORD=password

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# JWT
JWT_SECRET_KEY=your-secret-key
ACCESS_TOKEN_EXPIRE_MINUTES=15
REFRESH_TOKEN_EXPIRE_DAYS=30

# Email (SMTP Configuration)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your-email@gmail.com
SMTP_PASSWORD=your-app-password
SMTP_USE_TLS=true
FROM_EMAIL=noreply@example.com

# OAuth Providers (optional)
GOOGLE_CLIENT_ID=your-google-client-id
GITHUB_CLIENT_ID=your-github-client-id
```

### 📧 Email Configuration Guide

#### Gmail Setup

1. **Enable 2-Factor Authentication** in your Google Account
2. **Create an App Password**:
   - Go to [Google Account Security](https://myaccount.google.com/security)
   - Click "App passwords" (only available if 2FA is enabled)
   - Select "Mail" and "Windows Computer"
   - Copy the 16-character password

3. **Configure `.env`**:
   ```bash
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_USERNAME=your-email@gmail.com
   SMTP_PASSWORD=your-16-char-app-password
   SMTP_USE_TLS=true
   FROM_EMAIL=your-email@gmail.com
   ```

#### Alternative SMTP Providers

**Port 465 (Direct SSL)**:
```bash
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_USERNAME=your-email@gmail.com
SMTP_PASSWORD=your-app-password
```

**MailHog (Development)**:
```bash
SMTP_HOST=localhost
SMTP_PORT=1025
FROM_EMAIL=noreply@example.com
# No authentication needed for MailHog
```

#### Supported Ports

- **Port 587 (STARTTLS)**: Recommended for Gmail - Plain connection upgraded to TLS
- **Port 465 (Direct SSL)**: Alternative for Gmail - Direct encrypted connection
- **Port 1025 (MailHog)**: Development email testing without real SMTP

## 🏗️ Project Structure

```
src/
├── core/identity/          # Domain layer
│   ├── domains/            # Domain entities (User, Account)
│   ├── ports/              # Interface definitions
│   └── value_objects/      # Value objects and DTOs
├── application/identity/   # Application layer
│   ├── dtos/              # Data transfer objects
│   └── use_cases/         # Business use cases
├── infra/                 # Infrastructure layer
│   ├── db/                # Database configuration
│   ├── repos/             # Repository implementations
│   ├── auth/              # Authentication services
│   └── email/             # Email services
├── interfaces/api/        # API layer
│   ├── routes/            # FastAPI routes
│   └── responses/         # Response handlers
├── bootstrap/             # Dependency injection
└── shared/                # Shared utilities
```

## 🔒 Security Features

- **Password hashing** with bcrypt
- **JWT tokens** with configurable expiration
- **Account lockout** after failed attempts
- **Rate limiting** ready infrastructure
- **Input validation** with Pydantic
- **SQL injection protection** with ORM
- **CORS configuration** for API security

## 📦 Docker Support

Development environment with Docker Compose:

```bash
# Start all services
docker-compose -f docker/docker-compose.yml up -d

# Services included:
# - PostgreSQL (port 5432)
# - Redis (port 6379) 
# - MailHog (web UI on port 8025)
```

## 🤝 Contributing

1. Follow the hexagonal architecture principles
2. Add tests for new features
3. Update documentation as needed
4. Use type hints throughout
5. Follow PEP 8 style guidelines

## 📄 License

This project is licensed under the MIT License.