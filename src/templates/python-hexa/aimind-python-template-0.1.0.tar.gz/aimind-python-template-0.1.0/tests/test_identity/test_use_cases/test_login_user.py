import pytest
from unittest.mock import AsyncMock
from datetime import datetime

from application.identity.use_cases.login_user import LoginUserUseCase
from application.identity.dtos import LoginRequest
from core.identity.domains.user import User
from shared.constants.auth_providers_enum import UserStatus


class TestLoginUserUseCase:
    """Test cases for LoginUserUseCase."""

    @pytest.fixture
    def login_request(self) -> LoginRequest:
        return LoginRequest(email="test@example.com", password="password123")

    @pytest.fixture
    def use_case(
        self, mock_user_repo, mock_token_repo, mock_auth_service
    ) -> LoginUserUseCase:
        return LoginUserUseCase(
            user_repo=mock_user_repo,
            token_repo=mock_token_repo,
            auth_service=mock_auth_service,
        )

    async def test_login_success(
        self,
        use_case,
        login_request,
        mock_user_repo,
        mock_token_repo,
        mock_auth_service,
        sample_user,
    ):
        """Test successful login."""
        # Arrange
        sample_user.set_password("password123")
        mock_user_repo.get_by_email.return_value = sample_user
        mock_user_repo.update.return_value = sample_user
        mock_auth_service.generate_tokens.return_value = (
            "access_token",
            "refresh_token",
        )
        mock_token_repo.store_refresh_token.return_value = None

        # Act
        result = await use_case.execute(login_request)

        # Assert
        assert result.access_token == "access_token"
        assert result.refresh_token == "refresh_token"
        assert result.user.email == sample_user.email

        mock_user_repo.get_by_email.assert_called_once_with(login_request.email)
        mock_user_repo.update.assert_called_once()
        mock_auth_service.generate_tokens.assert_called_once()
        mock_token_repo.store_refresh_token.assert_called_once()

    async def test_login_invalid_email(self, use_case, login_request, mock_user_repo):
        """Test login with invalid email."""
        # Arrange
        mock_user_repo.get_by_email.return_value = None

        # Act & Assert
        with pytest.raises(ValueError, match="Invalid credentials"):
            await use_case.execute(login_request)

    async def test_login_invalid_password(
        self, use_case, login_request, mock_user_repo, sample_user
    ):
        """Test login with invalid password."""
        # Arrange
        sample_user.set_password("different_password")
        mock_user_repo.get_by_email.return_value = sample_user
        mock_user_repo.update.return_value = sample_user

        # Act & Assert
        with pytest.raises(ValueError, match="Invalid credentials"):
            await use_case.execute(login_request)

        mock_user_repo.update.assert_called_once()  # Failed attempt recorded
