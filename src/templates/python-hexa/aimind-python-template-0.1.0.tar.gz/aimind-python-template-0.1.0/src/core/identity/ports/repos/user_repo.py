from abc import abstractmethod
from typing import Optional

from shared.base.base_repo import BaseRepository
from core.identity.domains.user import User


class UserRepository(BaseRepository[User]):
    """User repository interface."""

    @abstractmethod
    async def get_by_email(self, email: str) -> Optional[User]:
        """Get user by email address."""
        pass

    @abstractmethod
    async def email_exists(self, email: str) -> bool:
        """Check if email already exists."""
        pass

    @abstractmethod
    async def get_with_accounts(self, user_id: int) -> Optional[User]:
        """Get user with associated accounts."""
        pass
