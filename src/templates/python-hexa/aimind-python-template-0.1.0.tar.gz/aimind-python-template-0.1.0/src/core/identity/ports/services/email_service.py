from abc import ABC, abstractmethod
from typing import Dict, Any


class EmailService(ABC):
    """Email service port interface."""

    @abstractmethod
    async def send_email(
        self,
        to_email: str,
        subject: str,
        template_name: str,
        template_data: Dict[str, Any],
    ) -> bool:
        """Send email using template."""
        pass

    @abstractmethod
    async def send_verification_email(self, email: str, token: str) -> bool:
        """Send email verification email."""
        pass

    @abstractmethod
    async def send_password_reset_email(self, email: str, token: str) -> bool:
        """Send password reset email."""
        pass

    @abstractmethod
    async def send_otp_email(self, email: str, otp_code: str) -> bool:
        """Send OTP code via email."""
        pass

    @abstractmethod
    async def send_welcome_email(self, email: str, first_name: str) -> bool:
        """Send welcome email after successful registration."""
        pass
