from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Dict, Any

from shared.constants.auth_providers_enum import TokenType, AuthProvider


@dataclass(frozen=True)
class EmailAddress:
    """Email address value object."""

    value: str

    def __post_init__(self):
        if not self._is_valid_email(self.value):
            raise ValueError(f"Invalid email address: {self.value}")

    def _is_valid_email(self, email: str) -> bool:
        """Basic email validation."""
        import re

        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        return re.match(pattern, email) is not None


@dataclass(frozen=True)
class AuthToken:
    """Authentication token value object."""

    value: str
    token_type: TokenType
    expires_at: Optional[datetime] = None

    def is_expired(self) -> bool:
        """Check if token is expired."""
        if not self.expires_at:
            return False
        return datetime.utcnow() > self.expires_at


@dataclass(frozen=True)
class OTPCode:
    """OTP code value object."""

    code: str
    expires_at: datetime

    def is_expired(self) -> bool:
        """Check if OTP is expired."""
        return datetime.utcnow() > self.expires_at

    def is_valid(self, input_code: str) -> bool:
        """Validate OTP code."""
        return not self.is_expired() and self.code == input_code


@dataclass(frozen=True)
class AuthCredentials:
    """Authentication credentials value object."""

    provider: AuthProvider
    email: Optional[str] = None
    password: Optional[str] = None
    provider_data: Optional[Dict[str, Any]] = None
