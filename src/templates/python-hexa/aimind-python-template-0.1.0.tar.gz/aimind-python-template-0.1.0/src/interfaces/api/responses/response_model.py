from typing import Optional, Any
from pydantic import BaseModel


class APIResponse(BaseModel):
    """Base API response model."""

    success: bool = True
    message: Optional[str] = None
    data: Optional[Any] = None


class ErrorResponse(BaseModel):
    """Error response model."""

    success: bool = False
    message: str
    errors: Optional[Any] = None
