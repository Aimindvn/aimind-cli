from typing import Optional

from core.identity.ports.repos.token_repo import TokenRepository
from infra.queue.redis import RedisConnection


class TokenRepositoryImpl(TokenRepository):
    """Token repository implementation using Redis."""

    def __init__(self):
        self.redis = None

    async def _get_redis(self):
        """Get Redis client."""
        if not self.redis:
            self.redis = await RedisConnection.get_client()
        return self.redis

    async def store_refresh_token(
        self, user_id: int, token: str, expires_in: int
    ) -> None:
        """Store refresh token in Redis."""
        redis_client = await self._get_redis()
        await redis_client.setex(f"refresh_token:{token}", expires_in, str(user_id))

    async def get_refresh_token(self, token: str) -> Optional[int]:
        """Get user ID by refresh token."""
        redis_client = await self._get_redis()
        user_id = await redis_client.get(f"refresh_token:{token}")
        return int(user_id) if user_id else None

    async def revoke_refresh_token(self, token: str) -> bool:
        """Revoke refresh token."""
        redis_client = await self._get_redis()
        result = await redis_client.delete(f"refresh_token:{token}")
        return result > 0

    async def store_email_token(self, email: str, token: str, expires_in: int) -> None:
        """Store email verification/reset token."""
        redis_client = await self._get_redis()
        await redis_client.setex(f"email_token:{token}", expires_in, email)

    async def get_email_token(self, token: str) -> Optional[str]:
        """Get email by token."""
        redis_client = await self._get_redis()
        return await redis_client.get(f"email_token:{token}")

    async def revoke_email_token(self, token: str) -> bool:
        """Revoke email token."""
        redis_client = await self._get_redis()
        result = await redis_client.delete(f"email_token:{token}")
        return result > 0

    async def store_otp_code(self, email: str, code: str, expires_in: int) -> None:
        """Store OTP code for email."""
        redis_client = await self._get_redis()
        await redis_client.setex(f"otp:{email}", expires_in, code)

    async def get_otp_code(self, email: str) -> Optional[str]:
        """Get OTP code for email."""
        redis_client = await self._get_redis()
        return await redis_client.get(f"otp:{email}")

    async def revoke_otp_code(self, email: str) -> bool:
        """Revoke OTP code for email."""
        redis_client = await self._get_redis()
        result = await redis_client.delete(f"otp:{email}")
        return result > 0
