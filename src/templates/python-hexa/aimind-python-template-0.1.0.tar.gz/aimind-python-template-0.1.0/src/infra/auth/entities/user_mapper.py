from typing import List
from core.identity.domains.user import User
from core.identity.domains.account import Account
from shared.constants.auth_providers_enum import UserStatus, AuthProvider
from .user import UserModel
from .account import AccountModel


class UserMapper:
    """Mapper for converting between User domain entity and UserModel infrastructure entity."""

    @staticmethod
    def model_to_domain(model: UserModel, accounts: List[Account] = None) -> User:
        """Convert UserModel to User domain entity."""
        return User(
            id=model.id,
            email=model.email,
            password_hash=model.password_hash,
            first_name=model.first_name,
            last_name=model.last_name,
            status=UserStatus(model.status),
            email_verified=model.email_verified,
            email_verified_at=model.email_verified_at,
            last_login_at=model.last_login_at,
            failed_login_attempts=model.failed_login_attempts,
            locked_until=model.locked_until,
            created_at=model.created_at,
            updated_at=model.updated_at,
            accounts=accounts or [],
        )

    @staticmethod
    def domain_to_model_data(entity: User) -> dict:
        """Convert User domain entity to model data dictionary."""
        return {
            "id": entity.id,
            "email": entity.email,
            "password_hash": entity.password_hash,
            "first_name": entity.first_name,
            "last_name": entity.last_name,
            "status": (
                entity.status.value
                if isinstance(entity.status, UserStatus)
                else entity.status
            ),
            "email_verified": entity.email_verified,
            "email_verified_at": entity.email_verified_at,
            "last_login_at": entity.last_login_at,
            "failed_login_attempts": entity.failed_login_attempts,
            "locked_until": entity.locked_until,
            "created_at": entity.created_at,
            "updated_at": entity.updated_at,
        }

    @staticmethod
    def update_model_from_domain(model: UserModel, entity: User) -> UserModel:
        """Update UserModel fields from User domain entity."""
        model.email = entity.email
        model.password_hash = entity.password_hash
        model.first_name = entity.first_name
        model.last_name = entity.last_name
        model.status = (
            entity.status.value
            if isinstance(entity.status, UserStatus)
            else entity.status
        )
        model.email_verified = entity.email_verified
        model.email_verified_at = entity.email_verified_at
        model.last_login_at = entity.last_login_at
        model.failed_login_attempts = entity.failed_login_attempts
        model.locked_until = entity.locked_until
        return model
