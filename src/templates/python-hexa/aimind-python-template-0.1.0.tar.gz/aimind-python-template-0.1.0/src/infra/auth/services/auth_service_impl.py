import secrets
import string
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Tuple
from jose import JWTError, jwt

from core.identity.ports.services.auth_service import AuthService
from core.identity.domains.user import User
from shared.constants.auth_providers_enum import TokenType
from shared.settings import get_settings

settings = get_settings()


class AuthServiceImpl(AuthService):
    """Authentication service implementation."""

    def __init__(self):
        self.secret_key = settings.jwt_secret_key
        self.algorithm = settings.jwt_algorithm
        self.access_token_expire_minutes = settings.access_token_expire_minutes
        self.refresh_token_expire_days = settings.refresh_token_expire_days

    async def generate_tokens(self, user: User) -> Tuple[str, str]:
        """Generate access and refresh tokens for user."""
        # Access token payload
        access_payload = {
            "sub": str(user.id),
            "email": user.email,
            "type": TokenType.ACCESS.value,
            "exp": datetime.utcnow()
            + timedelta(minutes=self.access_token_expire_minutes),
            "iat": datetime.utcnow(),
        }

        # Refresh token payload
        refresh_payload = {
            "sub": str(user.id),
            "type": TokenType.REFRESH.value,
            "exp": datetime.utcnow() + timedelta(days=self.refresh_token_expire_days),
            "iat": datetime.utcnow(),
        }

        access_token = jwt.encode(
            access_payload, self.secret_key, algorithm=self.algorithm
        )
        refresh_token = jwt.encode(
            refresh_payload, self.secret_key, algorithm=self.algorithm
        )

        return access_token, refresh_token

    async def verify_access_token(self, token: str) -> Optional[Dict[str, Any]]:
        """Verify and decode access token."""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            if payload.get("type") != TokenType.ACCESS.value:
                return None
            return payload
        except JWTError:
            return None

    async def generate_email_token(
        self, email: str, token_type: TokenType, expires_in: timedelta
    ) -> str:
        """Generate token for email verification or password reset."""
        payload = {
            "email": email,
            "type": token_type.value,
            "exp": datetime.utcnow() + expires_in,
            "iat": datetime.utcnow(),
        }
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)

    async def verify_email_token(
        self, token: str, token_type: TokenType
    ) -> Optional[str]:
        """Verify email token and return email if valid."""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=[self.algorithm])
            if payload.get("type") != token_type.value:
                return None
            return payload.get("email")
        except JWTError:
            return None

    async def generate_otp_code(self, email: str) -> str:
        """Generate OTP code for email."""
        return "".join(secrets.choice(string.digits) for _ in range(6))
