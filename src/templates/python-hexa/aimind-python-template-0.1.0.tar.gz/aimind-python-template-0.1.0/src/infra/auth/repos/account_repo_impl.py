from typing import Optional, List

from shared.base.base_repo_impl import BaseRepositoryImpl
from core.identity.ports.repos.account_repo import AccountRepository
from core.identity.domains.account import Account
from infra.auth.entities.account import AccountModel
from infra.auth.entities.account_mapper import AccountMapper
from shared.constants.auth_providers_enum import AuthProvider


class AccountRepositoryImpl(BaseRepositoryImpl[Account], AccountRepository):
    """Account repository implementation using Peewee and mappers."""

    def __init__(self):
        super().__init__(AccountModel, Account)
        self.account_mapper = AccountMapper()

    def _model_to_entity(self, model: AccountModel) -> Account:
        """Convert AccountModel to Account domain entity using mapper."""
        return self.account_mapper.model_to_domain(model)

    def _entity_to_model_data(self, entity: Account) -> dict:
        """Convert Account entity to model data using mapper."""
        return self.account_mapper.domain_to_model_data(entity)

    async def get_by_provider_and_user_id(
        self, provider: AuthProvider, provider_user_id: str
    ) -> Optional[Account]:
        """Get account by provider and provider user ID."""
        try:
            model = AccountModel.get(
                (AccountModel.provider == provider.value)
                & (AccountModel.provider_user_id == provider_user_id)
            )
            return self._model_to_entity(model)
        except AccountModel.DoesNotExist:
            return None

    async def get_by_user_id(self, user_id: int) -> List[Account]:
        """Get all accounts for a user."""
        models = AccountModel.select().where(AccountModel.user == user_id)
        return [self._model_to_entity(model) for model in models]

    async def get_by_provider_and_email(
        self, provider: AuthProvider, email: str
    ) -> Optional[Account]:
        """Get account by provider and email."""
        try:
            model = AccountModel.get(
                (AccountModel.provider == provider.value)
                & (AccountModel.provider_email == email)
            )
            return self._model_to_entity(model)
        except AccountModel.DoesNotExist:
            return None

    async def update(self, entity: Account) -> Account:
        """Update an account entity using mapper."""
        if not entity.id:
            raise ValueError("Entity must have an ID to update")

        try:
            # Get existing model
            model = AccountModel.get_by_id(entity.id)

            # Update model using mapper
            updated_model = self.account_mapper.update_model_from_domain(model, entity)
            updated_model.save()

            return self._model_to_entity(updated_model)
        except AccountModel.DoesNotExist:
            raise ValueError(f"Account with ID {entity.id} not found")
