import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, Any
from jinja2 import Environment, FileSystemLoader
import os

from core.identity.ports.services.email_service import EmailService
from shared.settings import get_settings

settings = get_settings()


class SMTPEmailService(EmailService):
    """SMTP email service implementation with proper TLS/STARTTLS support."""

    def __init__(self):
        self.smtp_host = settings.smtp_host
        self.smtp_port = settings.smtp_port
        self.smtp_username = settings.smtp_username
        self.smtp_password = settings.smtp_password
        self.smtp_use_tls = settings.smtp_use_tls
        self.from_email = settings.from_email

        # Setup Jinja2 for email templates
        template_dir = os.path.join(os.path.dirname(__file__), "templates")
        self.jinja_env = Environment(loader=FileSystemLoader(template_dir))

    async def send_email(
        self,
        to_email: str,
        subject: str,
        template_name: str,
        template_data: Dict[str, Any],
    ) -> bool:
        """Send email using template.

        Supports two TLS modes:
        - Port 587: STARTTLS (plain connection upgraded to TLS)
        - Port 465: Direct SSL (SSL from the start)
        """
        try:
            # Render email template
            template = self.jinja_env.get_template(f"{template_name}.html")
            html_content = template.render(**template_data)

            # Create message
            message = MIMEMultipart("alternative")
            message["Subject"] = subject
            message["From"] = self.from_email
            message["To"] = to_email

            # Add HTML part
            html_part = MIMEText(html_content, "html")
            message.attach(html_part)

            # Send email with proper TLS/STARTTLS handling
            # Port 465: Direct SSL connection (implicit TLS)
            # Port 587: STARTTLS (plain connection upgraded to TLS)
            if self.smtp_port == 465:
                # Implicit SSL: TLS from the start
                async with aiosmtplib.SMTP(
                    hostname=self.smtp_host,
                    port=self.smtp_port,
                    use_tls=True,
                ) as smtp:
                    if self.smtp_username and self.smtp_password:
                        await smtp.login(self.smtp_username, self.smtp_password)
                    await smtp.send_message(message)
            else:
                # STARTTLS: Plain connection, then upgrade to TLS
                async with aiosmtplib.SMTP(
                    hostname=self.smtp_host,
                    port=self.smtp_port,
                ) as smtp:
                    # Call starttls to upgrade the connection
                    # If already TLS, aiosmtplib will handle it gracefully
                    try:
                        await smtp.starttls()
                    except Exception:
                        # Connection might already be TLS, continue anyway
                        pass

                    if self.smtp_username and self.smtp_password:
                        await smtp.login(self.smtp_username, self.smtp_password)
                    await smtp.send_message(message)

            return True
        except Exception as e:
            # Log error in production
            print(f"Failed to send email: {e}")
            return False

    async def send_verification_email(self, email: str, token: str) -> bool:
        """Send email verification email."""
        verification_url = f"{settings.frontend_url}/verify-email?token={token}"
        return await self.send_email(
            email,
            "Verify Your Email Address",
            "email_verification",
            {
                "email": email,
                "verification_url": verification_url,
                "app_name": settings.app_name,
            },
        )

    async def send_password_reset_email(self, email: str, token: str) -> bool:
        """Send password reset email."""
        reset_url = f"{settings.frontend_url}/reset-password?token={token}"
        return await self.send_email(
            email,
            "Reset Your Password",
            "password_reset",
            {"email": email, "reset_url": reset_url, "app_name": settings.app_name},
        )

    async def send_otp_email(self, email: str, otp_code: str) -> bool:
        """Send OTP code via email."""
        return await self.send_email(
            email,
            "Your OTP Code",
            "otp_code",
            {"email": email, "otp_code": otp_code, "app_name": settings.app_name},
        )

    async def send_welcome_email(self, email: str, first_name: str) -> bool:
        """Send welcome email after successful registration."""
        return await self.send_email(
            email,
            f"Welcome to {settings.app_name}!",
            "welcome",
            {"first_name": first_name, "email": email, "app_name": settings.app_name},
        )
