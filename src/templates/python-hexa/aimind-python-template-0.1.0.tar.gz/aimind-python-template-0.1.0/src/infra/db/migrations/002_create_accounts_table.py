"""Migration: Create accounts table."""

from infra.db.migration import Migration
from infra.db.db import db


class CreateAccountsTable(Migration):
    """Create the accounts table."""

    async def up(self):
        """Create accounts table."""
        db.execute_sql(
            """
            CREATE TABLE IF NOT EXISTS accounts (
                id SERIAL PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                provider VARCHAR(50) NOT NULL,
                provider_user_id VARCHAR(255) NOT NULL,
                provider_username VARCHAR(255),
                provider_email VARCHAR(255),
                access_token TEXT,
                refresh_token TEXT,
                expires_at TIMESTAMP NULL,
                token_type VARCHAR(50) DEFAULT 'Bearer',
                scope VARCHAR(500),
                provider_data JSONB DEFAULT '{}',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(provider, provider_user_id)
            )
            """
        )

        # Create index for faster queries
        db.execute_sql(
            "CREATE INDEX IF NOT EXISTS idx_accounts_user_id ON accounts(user_id)"
        )
        db.execute_sql(
            "CREATE INDEX IF NOT EXISTS idx_accounts_provider_email ON accounts(provider, provider_email)"
        )

    async def down(self):
        """Drop accounts table."""
        db.execute_sql("DROP TABLE IF EXISTS accounts")
