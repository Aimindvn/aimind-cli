from dependency_injector import providers

from application.identity.use_cases.register_user import RegisterUserUseCase
from application.identity.use_cases.login_user import LoginUserUseCase
from application.identity.use_cases.verify_email import VerifyEmailUseCase
from application.identity.use_cases.forgot_password import ForgotPasswordUseCase
from application.identity.use_cases.reset_password import ResetPasswordUseCase
from application.identity.use_cases.generate_otp import GenerateOTPUseCase
from application.identity.use_cases.verify_otp import VerifyOTPUseCase
from application.identity.use_cases.refresh_token import RefreshTokenUseCase


def configure_use_cases(
    user_repo, account_repo, token_repo, auth_service, email_service
) -> dict:
    """Configure use case dependencies."""
    return {
        "register_user_use_case": providers.Factory(
            RegisterUserUseCase,
            user_repo=user_repo,
            auth_service=auth_service,
            email_service=email_service,
        ),
        "login_user_use_case": providers.Factory(
            LoginUserUseCase,
            user_repo=user_repo,
            token_repo=token_repo,
            auth_service=auth_service,
        ),
        "verify_email_use_case": providers.Factory(
            VerifyEmailUseCase,
            user_repo=user_repo,
            auth_service=auth_service,
            email_service=email_service,
        ),
        "forgot_password_use_case": providers.Factory(
            ForgotPasswordUseCase,
            user_repo=user_repo,
            auth_service=auth_service,
            email_service=email_service,
        ),
        "reset_password_use_case": providers.Factory(
            ResetPasswordUseCase,
            user_repo=user_repo,
            auth_service=auth_service,
        ),
        "generate_otp_use_case": providers.Factory(
            GenerateOTPUseCase,
            user_repo=user_repo,
            token_repo=token_repo,
            auth_service=auth_service,
            email_service=email_service,
        ),
        "verify_otp_use_case": providers.Factory(
            VerifyOTPUseCase,
            user_repo=user_repo,
            token_repo=token_repo,
            auth_service=auth_service,
        ),
        "refresh_token_use_case": providers.Factory(
            RefreshTokenUseCase,
            user_repo=user_repo,
            token_repo=token_repo,
            auth_service=auth_service,
        ),
    }
