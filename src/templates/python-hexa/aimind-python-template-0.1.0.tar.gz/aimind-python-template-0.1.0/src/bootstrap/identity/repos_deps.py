from dependency_injector import providers

from infra.auth.repos.user_repo_impl import UserRepositoryImpl
from infra.auth.repos.account_repo_impl import AccountRepositoryImpl
from infra.auth.repos.token_repo_impl import TokenRepositoryImpl


def configure_repos() -> dict:
    """Configure repository dependencies."""
    return {
        "user_repository": providers.Singleton(UserRepositoryImpl),
        "account_repository": providers.Singleton(AccountRepositoryImpl),
        "token_repository": providers.Singleton(TokenRepositoryImpl),
    }
