from shared.base.base_use_case import BaseUseCase
from application.identity.dtos import ResetPasswordRequest, MessageResponse
from core.identity.ports.repos.user_repo import UserRepository
from core.identity.ports.services.auth_service import AuthService
from shared.constants.auth_providers_enum import TokenType


class ResetPasswordUseCase(BaseUseCase[ResetPasswordRequest, MessageResponse]):
    """Reset password use case."""

    def __init__(self, user_repo: UserRepository, auth_service: AuthService):
        self.user_repo = user_repo
        self.auth_service = auth_service

    async def execute(self, request: ResetPasswordRequest) -> MessageResponse:
        """Execute password reset."""
        # Verify token
        email = await self.auth_service.verify_email_token(
            request.token, TokenType.PASSWORD_RESET
        )

        if not email:
            raise ValueError("Invalid or expired reset token")

        # Get user by email
        user = await self.user_repo.get_by_email(email)
        if not user:
            raise ValueError("User not found")

        # Set new password
        user.set_password(request.new_password)

        # Reset failed attempts and unlock if locked
        user.failed_login_attempts = 0
        user.locked_until = None

        # Update user
        await self.user_repo.update(user)

        return MessageResponse(message="Password has been reset successfully")
