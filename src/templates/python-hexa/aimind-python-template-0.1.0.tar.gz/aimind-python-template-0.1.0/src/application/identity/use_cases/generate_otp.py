from shared.base.base_use_case import BaseUseCase
from application.identity.dtos import ForgotPasswordRequest, MessageResponse
from core.identity.ports.repos.user_repo import UserRepository
from core.identity.ports.repos.token_repo import TokenRepository
from core.identity.ports.services.auth_service import AuthService
from core.identity.ports.services.email_service import EmailService


class GenerateOTPUseCase(BaseUseCase[ForgotPasswordRequest, MessageResponse]):
    """Generate OTP code use case."""

    def __init__(
        self,
        user_repo: UserRepository,
        token_repo: TokenRepository,
        auth_service: AuthService,
        email_service: EmailService,
    ):
        self.user_repo = user_repo
        self.token_repo = token_repo
        self.auth_service = auth_service
        self.email_service = email_service

    async def execute(self, request: ForgotPasswordRequest) -> MessageResponse:
        """Execute OTP generation."""
        # Check if user exists
        user = await self.user_repo.get_by_email(request.email)
        if not user:
            # Don't reveal if email exists or not for security
            return MessageResponse(
                message="If the email exists, an OTP code has been sent."
            )

        # Generate OTP code
        otp_code = await self.auth_service.generate_otp_code(request.email)

        # Store OTP in Redis (5 minutes expiry)
        await self.token_repo.store_otp_code(request.email, otp_code, 5 * 60)

        # Send OTP via email
        await self.email_service.send_otp_email(request.email, otp_code)

        return MessageResponse(
            message="If the email exists, an OTP code has been sent."
        )
