from datetime import datetime, timedelta

from shared.base.base_use_case import BaseUseCase
from application.identity.dtos import LoginRequest, AuthTokenResponse, UserResponse
from core.identity.ports.repos.user_repo import UserRepository
from core.identity.ports.repos.token_repo import TokenRepository
from core.identity.ports.services.auth_service import AuthService
from core.identity.domains.user import User
from shared.constants.auth_providers_enum import UserStatus


class LoginUserUseCase(BaseUseCase[LoginRequest, AuthTokenResponse]):
    """User login use case."""

    def __init__(
        self,
        user_repo: UserRepository,
        token_repo: TokenRepository,
        auth_service: AuthService,
    ):
        self.user_repo = user_repo
        self.token_repo = token_repo
        self.auth_service = auth_service

    async def execute(self, request: LoginRequest) -> AuthTokenResponse:
        """Execute user login."""
        # Get user by email
        user = await self.user_repo.get_by_email(request.email)
        if not user:
            raise ValueError("Invalid credentials")

        # Check if user can login
        if not user.can_login():
            if user.status == UserStatus.PENDING:
                raise ValueError("Please verify your email address first")
            elif user.locked_until and user.locked_until > datetime.utcnow():
                raise ValueError(
                    "Account is temporarily locked due to failed login attempts"
                )
            else:
                raise ValueError("Account is not active")

        # Verify password
        if not user.verify_password(request.password):
            # Record failed attempt
            user.record_failed_login()
            await self.user_repo.update(user)
            raise ValueError("Invalid credentials")

        # Record successful login
        user.record_successful_login()
        await self.user_repo.update(user)

        # Generate tokens
        access_token, refresh_token = await self.auth_service.generate_tokens(user)

        # Store refresh token in Redis
        refresh_token_expires = 30 * 24 * 60 * 60  # 30 days in seconds
        await self.token_repo.store_refresh_token(
            user.id, refresh_token, refresh_token_expires
        )

        return AuthTokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_in=15 * 60,  # 15 minutes
            user=UserResponse(
                id=user.id,
                email=user.email,
                first_name=user.first_name,
                last_name=user.last_name,
                status=user.status,
                email_verified=user.email_verified,
                created_at=user.created_at,
                last_login_at=user.last_login_at,
            ),
        )
