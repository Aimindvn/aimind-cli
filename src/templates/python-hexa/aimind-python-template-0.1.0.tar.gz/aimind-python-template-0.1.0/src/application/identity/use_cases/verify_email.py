from shared.base.base_use_case import BaseUseCase
from application.identity.dtos import VerifyEmailRequest, MessageResponse
from core.identity.ports.repos.user_repo import UserRepository
from core.identity.ports.services.auth_service import AuthService
from core.identity.ports.services.email_service import EmailService
from shared.constants.auth_providers_enum import TokenType


class VerifyEmailUseCase(BaseUseCase[VerifyEmailRequest, MessageResponse]):
    """Verify email address use case."""

    def __init__(
        self,
        user_repo: UserRepository,
        auth_service: AuthService,
        email_service: EmailService,
    ):
        self.user_repo = user_repo
        self.auth_service = auth_service
        self.email_service = email_service

    async def execute(self, request: VerifyEmailRequest) -> MessageResponse:
        """Execute email verification."""
        # Verify token
        email = await self.auth_service.verify_email_token(
            request.token, TokenType.EMAIL_VERIFICATION
        )

        if not email:
            raise ValueError("Invalid or expired verification token")

        # Get user by email
        user = await self.user_repo.get_by_email(email)
        if not user:
            raise ValueError("User not found")

        # Check if already verified
        if user.email_verified:
            return MessageResponse(message="Email is already verified")

        # Verify email
        user.verify_email()
        await self.user_repo.update(user)

        # Send welcome email
        await self.email_service.send_welcome_email(user.email, user.first_name)

        return MessageResponse(
            message="Email verified successfully! Welcome to our platform."
        )
