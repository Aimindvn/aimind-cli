from datetime import timedelta

from shared.base.base_use_case import BaseUseCase
from application.identity.dtos import ForgotPasswordRequest, MessageResponse
from core.identity.ports.repos.user_repo import UserRepository
from core.identity.ports.services.auth_service import AuthService
from core.identity.ports.services.email_service import EmailService
from shared.constants.auth_providers_enum import TokenType


class ForgotPasswordUseCase(BaseUseCase[ForgotPasswordRequest, MessageResponse]):
    """Forgot password use case."""

    def __init__(
        self,
        user_repo: UserRepository,
        auth_service: AuthService,
        email_service: EmailService,
    ):
        self.user_repo = user_repo
        self.auth_service = auth_service
        self.email_service = email_service

    async def execute(self, request: ForgotPasswordRequest) -> MessageResponse:
        """Execute forgot password."""
        # Check if user exists
        user = await self.user_repo.get_by_email(request.email)
        if not user:
            # Don't reveal if email exists or not for security
            return MessageResponse(
                message="If the email exists, a password reset link has been sent."
            )

        # Generate password reset token
        reset_token = await self.auth_service.generate_email_token(
            request.email, TokenType.PASSWORD_RESET, timedelta(hours=1)  # 1 hour expiry
        )

        # Send password reset email
        await self.email_service.send_password_reset_email(request.email, reset_token)

        return MessageResponse(
            message="If the email exists, a password reset link has been sent."
        )
