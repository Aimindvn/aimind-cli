from datetime import timedelta
from typing import Optional

from shared.base.base_use_case import BaseUseCase
from application.identity.dtos import RegisterRequest, UserResponse, MessageResponse
from core.identity.ports.repos.user_repo import UserRepository
from core.identity.ports.services.auth_service import AuthService
from core.identity.ports.services.email_service import EmailService
from core.identity.domains.user import User
from core.identity.value_objects import EmailAddress
from shared.constants.auth_providers_enum import UserStatus, TokenType


class RegisterUserUseCase(BaseUseCase[RegisterRequest, UserResponse]):
    """Register new user use case."""

    def __init__(
        self,
        user_repo: UserRepository,
        auth_service: AuthService,
        email_service: EmailService,
    ):
        self.user_repo = user_repo
        self.auth_service = auth_service
        self.email_service = email_service

    async def execute(self, request: RegisterRequest) -> UserResponse:
        """Execute user registration."""
        # Validate email format
        email_vo = EmailAddress(request.email)

        # Check if user already exists
        if await self.user_repo.email_exists(request.email):
            raise ValueError("Email already registered")

        # Create user domain entity
        user = User(
            email=request.email,
            first_name=request.first_name,
            last_name=request.last_name,
            status=UserStatus.PENDING,
        )

        # Set password
        user.set_password(request.password)

        # Save user
        created_user = await self.user_repo.create(user)

        # Generate email verification token
        verification_token = await self.auth_service.generate_email_token(
            request.email,
            TokenType.EMAIL_VERIFICATION,
            timedelta(hours=24),  # 24 hours expiry
        )

        # Send verification email
        await self.email_service.send_verification_email(
            request.email, verification_token
        )

        return UserResponse(
            id=created_user.id,
            email=created_user.email,
            first_name=created_user.first_name,
            last_name=created_user.last_name,
            status=created_user.status,
            email_verified=created_user.email_verified,
            created_at=created_user.created_at,
        )
