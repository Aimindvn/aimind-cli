from shared.base.base_use_case import BaseUseCase
from application.identity.dtos import (
    RefreshTokenRequest,
    AuthTokenResponse,
    UserResponse,
)
from core.identity.ports.repos.user_repo import UserRepository
from core.identity.ports.repos.token_repo import TokenRepository
from core.identity.ports.services.auth_service import AuthService


class RefreshTokenUseCase(BaseUseCase[RefreshTokenRequest, AuthTokenResponse]):
    """Refresh access token use case."""

    def __init__(
        self,
        user_repo: UserRepository,
        token_repo: TokenRepository,
        auth_service: AuthService,
    ):
        self.user_repo = user_repo
        self.token_repo = token_repo
        self.auth_service = auth_service

    async def execute(self, request: RefreshTokenRequest) -> AuthTokenResponse:
        """Execute token refresh."""
        # Get user ID from refresh token
        user_id = await self.token_repo.get_refresh_token(request.refresh_token)
        if not user_id:
            raise ValueError("Invalid refresh token")

        # Get user
        user = await self.user_repo.get_by_id(user_id)
        if not user:
            raise ValueError("User not found")

        # Check if user can still login
        if not user.can_login():
            # Revoke refresh token
            await self.token_repo.revoke_refresh_token(request.refresh_token)
            raise ValueError("User account is not active")

        # Generate new tokens
        access_token, new_refresh_token = await self.auth_service.generate_tokens(user)

        # Revoke old refresh token
        await self.token_repo.revoke_refresh_token(request.refresh_token)

        # Store new refresh token
        refresh_token_expires = 30 * 24 * 60 * 60  # 30 days in seconds
        await self.token_repo.store_refresh_token(
            user.id, new_refresh_token, refresh_token_expires
        )

        return AuthTokenResponse(
            access_token=access_token,
            refresh_token=new_refresh_token,
            expires_in=15 * 60,  # 15 minutes
            user=UserResponse(
                id=user.id,
                email=user.email,
                first_name=user.first_name,
                last_name=user.last_name,
                status=user.status,
                email_verified=user.email_verified,
                created_at=user.created_at,
                last_login_at=user.last_login_at,
            ),
        )
