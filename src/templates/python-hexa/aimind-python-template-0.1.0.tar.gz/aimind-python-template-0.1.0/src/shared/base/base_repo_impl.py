from typing import Optional, List, TypeVar, Type
from peewee import Model

from shared.base.base_repo import BaseRepository

T = TypeVar("T")
M = TypeVar("M", bound=Model)


class BaseRepositoryImpl(BaseRepository[T]):
    """Base repository implementation using Peewee."""

    def __init__(self, model_class: Type[M], entity_class: Type[T]):
        self.model_class = model_class
        self.entity_class = entity_class

    def _model_to_entity(self, model: M) -> T:
        """Convert Peewee model to domain entity."""
        # This is a basic implementation - you might need custom mapping
        data = model.__data__.copy()
        return self.entity_class(**data)

    def _entity_to_model_data(self, entity: T) -> dict:
        """Convert domain entity to model data."""
        # Basic implementation - adjust as needed
        if hasattr(entity, "__dict__"):
            return {k: v for k, v in entity.__dict__.items() if not k.startswith("_")}
        return {}

    async def create(self, entity: T) -> T:
        """Create a new entity."""
        data = self._entity_to_model_data(entity)
        data.pop("id", None)  # Remove ID for creation
        model = self.model_class.create(**data)
        return self._model_to_entity(model)

    async def get_by_id(self, entity_id: int) -> Optional[T]:
        """Get entity by ID."""
        try:
            model = self.model_class.get_by_id(entity_id)
            return self._model_to_entity(model)
        except self.model_class.DoesNotExist:
            return None

    async def update(self, entity: T) -> T:
        """Update an entity."""
        data = self._entity_to_model_data(entity)
        entity_id = data.pop("id")

        query = self.model_class.update(**data).where(self.model_class.id == entity_id)
        query.execute()

        updated_model = self.model_class.get_by_id(entity_id)
        return self._model_to_entity(updated_model)

    async def delete(self, entity_id: int) -> bool:
        """Delete an entity by ID."""
        try:
            model = self.model_class.get_by_id(entity_id)
            model.delete_instance()
            return True
        except self.model_class.DoesNotExist:
            return False

    async def list(self, offset: int = 0, limit: int = 100) -> List[T]:
        """List entities with pagination."""
        models = self.model_class.select().offset(offset).limit(limit)
        return [self._model_to_entity(model) for model in models]
