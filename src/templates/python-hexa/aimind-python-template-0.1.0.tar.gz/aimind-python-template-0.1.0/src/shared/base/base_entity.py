from datetime import datetime
from typing import Optional
from dataclasses import dataclass


@dataclass
class BaseEntity:
    """Base entity class for all domain entities."""

    id: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    def is_new(self) -> bool:
        """Check if entity is new (not persisted yet)."""
        return self.id is None
