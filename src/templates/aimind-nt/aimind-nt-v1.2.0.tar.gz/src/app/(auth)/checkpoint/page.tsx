"use client";

import { signOut, useSession } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function DashboardPage() {
  const { data: session, status } = useSession();

  if (status === "loading") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        Loading...
      </div>
    );
  }

  if (status === "unauthenticated") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        Unauthorized
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background text-foreground">
      <main className="w-full max-w-3xl px-8 py-24">
        <Card className="p-10">
          <div className="space-y-6">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold">
                Welcome {session?.user?.name}!
              </h1>
              <p className="text-gray-500">{session?.user?.email}</p>
            </div>

            <div className="space-y-2">
              <p className="text-sm text-gray-600">
                You have successfully logged in! This page is protected and can
                only be accessed by authenticated users. You can now explore the
                features and content available to you.
              </p>
            </div>

            <Button
              onClick={() => signOut()}
              variant="outline"
              className="w-full"
            >
              Sign Out
            </Button>
          </div>
        </Card>
      </main>
    </div>
  );
}
